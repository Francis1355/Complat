# OcrendBB
Sistema foro OPEN SOURCE, en desarrollo activo con un curso seguido a través de YouTube
