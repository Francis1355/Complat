<?php 
	echo "ERROR  404 NOT FOUND";
?>