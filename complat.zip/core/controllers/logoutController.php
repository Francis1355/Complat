<?php 
	unset($_SESSION['app_id']);
	header('location: ?view=home');
?>